puts 'meu nome e: '
variavel = gets
puts "o meu nome e #{variavel}"
