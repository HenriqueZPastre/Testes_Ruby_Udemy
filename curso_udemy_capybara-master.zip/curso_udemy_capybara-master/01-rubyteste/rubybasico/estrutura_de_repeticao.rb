i = 1

while i <= 10
    puts "sou verdadeiro #{i}"
    i += 1
end

j = 10

until j <= 1
    puts "sou falso #{j}"
    j -= 1
end