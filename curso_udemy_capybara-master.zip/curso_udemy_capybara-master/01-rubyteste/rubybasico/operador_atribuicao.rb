a = 2

#a = a + 1
a += 1
puts a

b = 2

#b = b - 1
b -= 1
 puts b 