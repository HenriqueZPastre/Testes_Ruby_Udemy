tipo 
inteiro
1,2,3,4,5

float
1,2 
1,23434567
01,45567


string ou caracteres

'string'
"string"
'1'
"2"

1 + '2'
boleano
true 
false