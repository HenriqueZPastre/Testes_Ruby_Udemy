

# comentario de uma linha
#fazer comentario


=begin
texto enorme
texto enorme
texto enorme
texto enorme
=end
texto enorme
texto enorme
texto enorme
texto enorme
