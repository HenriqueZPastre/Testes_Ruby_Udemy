variavel = 'bruno'

puts 'ola ' + variavel
puts 'ola ' << variavel


variavel_inteira = 2
variavel_string = 'total e'


puts "#{variavel_string}" +  "#{variavel_inteira}"