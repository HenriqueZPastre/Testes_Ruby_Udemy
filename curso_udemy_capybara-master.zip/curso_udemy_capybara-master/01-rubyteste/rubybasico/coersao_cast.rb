variavel = '1'
variavel2 = 2


puts variavel.to_i + 2