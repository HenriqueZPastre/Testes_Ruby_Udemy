#operadores

=begin
+ adicao
- subtracao
* multiplicacao
/ divisao
% modulo(pega o resto da divisao)
** exponenciacao (2 elevado a 2)
=end

puts  2 + 2
puts  2 - 2
puts  2 * 2
puts  10 / 2
puts  10 % 2
puts   2 ** 2
