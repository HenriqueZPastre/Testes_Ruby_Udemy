
puts "2 e maior que 1 #{2 > 1}" # imprime true
 
puts "2 e maior que 1 #{2 < 1}" # imprime falso

puts "2 e maior que 2 #{2 == 2}" #imprime true

puts "2 e maior que 1 #{2 >= 1}" #true

puts "2 e maior que 1 #{2 <= 1}" #false

puts "2 e maior que 1 #{2 != 1}" #true


puts "2 e maior que 1 #{2 <=> 3}" #imprime -1
puts "2 e maior que 1 #{2 <=> 2}" #imprime 0
puts "2 e maior que 1 #{2 <=> 1}" #imprime 1