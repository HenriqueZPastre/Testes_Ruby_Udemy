

#      0,1,2,3,4 
#vetor[1,2,3,4,5]
#
#
#hash = {"keys", "valor"}
#
#
#hashes = {"a" => "1","b" => "2"}
#hashes["a"]
#hashes = {:a => "1",:b => "2"}
#hashes[:a]

#vetor = [1,2,7,8,9,3,4,5]
#
#vetor.each do |i|
#    puts i
#end


#(1...5).each do |i|
#    puts i
#
#        
#    end
#
#    (1..5).each do |i|
#        puts i    
#        end

50.times{puts 'bruno'}