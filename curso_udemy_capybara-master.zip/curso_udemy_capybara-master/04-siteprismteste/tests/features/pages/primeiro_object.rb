class PrimeiroObject < SitePrism::Page
    
#mapear os elementos
#fazer nossos metodos

#@page = PrimeiroObject.new

#@page.elemento.click
#@page.metoto


end