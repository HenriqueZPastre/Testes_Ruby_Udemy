Quando("preencho o formulario.") do
   home.load
   home.preencher
end