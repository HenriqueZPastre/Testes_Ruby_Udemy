Quando("clico no elemento da sessao.") do 
    @pagina = Pagina.new
    @pagina.load

    @pagina.navebar.medium.click
    

end