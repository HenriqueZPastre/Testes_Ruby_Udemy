Quando("preencho o formulario.") do
    home.load
    home.preencher
    #@mapeando = MapeamendoElementoPage.new
    #@mapeando.load
    #@mapeando.preencher
    #mesma coisa q chamar o metodo.
    #@mapeando.nome.set 'Lucas'
    
end