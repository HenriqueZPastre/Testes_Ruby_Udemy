Quando("preencho os campos.") do
    @pagina_iframe = PaginaPadrao.new
    @pagina_iframe.load

    @pagina_iframe.preencher_campo do |frame|
        frame.nome.set 'Henrique'
        frame.sobrenome.set 'Pastre'
        
    end

end
