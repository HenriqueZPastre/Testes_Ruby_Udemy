Dir[File.join(File.dirname(__FILE__), '../pages/*._page.rb')].each { |file| required file}

module PagesObjects
    def home
        @home ||= MapeamendoElementoPage.new
    end
end