class PaginaInicial < SitePrism::Page
    set_url '/treinamento/home'
end